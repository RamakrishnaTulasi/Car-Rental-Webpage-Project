import React from 'react';
import { Clock, Shield, MapPin, ThumbsUp } from 'lucide-react';

const features = [
  {
    icon: <Clock className="h-8 w-8 text-orange-500" />,
    title: 'Punctual Service',
    description: 'We value your time and ensure our drivers arrive promptly for pickups.'
  },
  {
    icon: <Shield className="h-8 w-8 text-orange-500" />,
    title: 'Safety First',
    description: 'All our vehicles undergo regular maintenance to ensure your safety.'
  },
  {
    icon: <MapPin className="h-8 w-8 text-orange-500" />,
    title: 'Local Expertise',
    description: 'Our drivers have extensive knowledge of Guntur and surrounding areas.'
  },
  {
    icon: <ThumbsUp className="h-8 w-8 text-orange-500" />,
    title: 'Customer Satisfaction',
    description: 'We go the extra mile to ensure your journey is comfortable and enjoyable.'
  }
];

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">About Us</h2>
          <div className="w-20 h-1 bg-orange-500 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            At Champcar Rentals, we provide comfortable and reliable car travel services in Guntur. 
            Whether it's a quick city trip or a long journey, our fleet of clean and well-maintained 
            vehicles, along with experienced drivers, ensures your travel is safe and pleasant.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-8 text-center hover:shadow-lg transition-shadow duration-300">
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
import React from 'react';
import { ChevronDown } from 'lucide-react';

const Hero = () => {
  const scrollToBooking = () => {
    const element = document.getElementById('booking');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home" 
      className="relative h-screen flex items-center justify-center bg-cover bg-center text-white"
      style={{ backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("https://images.pexels.com/photos/12176260/pexels-photo-12176260.jpeg?auto=compress&cs=tinysrgb&w=1920")' }}
    >
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
          Experience Luxury on Every Journey
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
          Premium car rental services in Guntur with a fleet that defines class and comfort.
        </p>
        <button 
          onClick={scrollToBooking}
          className="bg-indigo-600 text-white font-bold py-3 px-8 rounded-full hover:bg-indigo-700 transition-colors duration-300 text-lg shadow-lg hover:shadow-xl"
        >
          Book Now
        </button>
      </div>
      
      <div className="absolute bottom-8 left-0 right-0 flex justify-center animate-bounce">
        <button 
          onClick={() => {
            const element = document.getElementById('about');
            if (element) {
              element.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          className="text-white focus:outline-none"
        >
          <ChevronDown className="h-12 w-12" />
        </button>
      </div>
    </section>
  );
};

export default Hero;
import React, { useState } from 'react';
import { Calculator, Clock, MapPin, Car } from 'lucide-react';

const PriceCalculator = () => {
  const [distance, setDistance] = useState('');
  const [hours, setHours] = useState('');
  const [vehicleType, setVehicleType] = useState('luxury');
  const [total, setTotal] = useState<number | null>(null);

  const calculatePrice = (e: React.FormEvent) => {
    e.preventDefault();
    
    const baseRates = {
      luxury: 75,
      suv: 65,
      sedan: 55
    };

    const distanceRate = baseRates[vehicleType as keyof typeof baseRates];
    const hourlyRate = distanceRate * 0.75;

    const distanceCost = parseFloat(distance) * distanceRate;
    const hoursCost = parseFloat(hours) * hourlyRate;

    setTotal(distanceCost + hoursCost);
  };

  return (
    <div>
      <form onSubmit={calculatePrice} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>Distance (miles)</span>
              </div>
            </label>
            <input
              type="number"
              min="0"
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter distance"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>Duration (hours)</span>
              </div>
            </label>
            <input
              type="number"
              min="0"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter hours"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center gap-2">
              <Car className="w-4 h-4" />
              <span>Vehicle Type</span>
            </div>
          </label>
          <select
            value={vehicleType}
            onChange={(e) => setVehicleType(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="luxury">Luxury Vehicle</option>
            <option value="suv">SUV</option>
            <option value="sedan">Sedan</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-900 text-white py-3 rounded-lg hover:bg-blue-800 transition-colors duration-200 flex items-center justify-center gap-2"
        >
          <Calculator className="w-5 h-5" />
          Calculate Price
        </button>
      </form>

      {total !== null && (
        <div className="mt-8 p-6 bg-blue-50 rounded-lg">
          <h3 className="text-xl font-semibold text-blue-900 mb-2">Estimated Total</h3>
          <p className="text-3xl font-bold text-blue-900">${total.toFixed(2)}</p>
          <p className="text-sm text-blue-700 mt-2">
            *Final price may vary based on additional services and actual travel conditions
          </p>
        </div>
      )}
    </div>
  );
};

export default PriceCalculator;
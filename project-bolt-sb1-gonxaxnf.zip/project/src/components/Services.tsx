import React from 'react';
import { Users } from 'lucide-react';

const carTypes = [
  {
    type: '7-Seater Cars',
    icon: <Users className="h-10 w-10 text-orange-500" />,
    models: ['Innova', 'Innova', 'Defender'],
    pricing: [
      '₹2500 for 24 hours (limit: 400 km)',
      '₹1500 for 12 hours (limit: 400 km)',
      'After 400 km: ₹7/km extra'
    ],
    image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    type: '5-Seater Cars',
    icon: <Users className="h-10 w-10 text-orange-500" />,
    models: ['Boleno', 'Brezza', 'i20'],
    pricing: [
      '₹2000 for 24 hours (limit: 200 km)',
      '₹1000 for 12 hours (limit: 200 km)',
      'After 200 km: ₹5/km extra'
    ],
    image: 'https://images.pexels.com/photos/112460/pexels-photo-112460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Our Services</h2>
          <div className="w-20 h-1 bg-orange-500 mx-auto mb-8"></div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We offer a variety of well-maintained vehicles to suit your travel needs, 
            whether you're traveling solo, with family, or in a group.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {carTypes.map((car, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="h-64 overflow-hidden">
                <img 
                  src={car.image} 
                  alt={car.type} 
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  {car.icon}
                  <h3 className="text-2xl font-bold text-gray-800 ml-3">{car.type}</h3>
                </div>
                
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">Available Models:</h4>
                  <div className="flex flex-wrap gap-2">
                    {car.models.map((model, i) => (
                      <span key={i} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                        {model}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold text-gray-700 mb-2">Pricing:</h4>
                  <ul className="space-y-2">
                    {car.pricing.map((price, i) => (
                      <li key={i} className="flex items-center text-gray-600">
                        <span className="inline-block w-2 h-2 bg-orange-500 rounded-full mr-3"></span>
                        {price}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;